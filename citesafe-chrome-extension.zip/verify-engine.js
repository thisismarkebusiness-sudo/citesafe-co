/**
 * CiteSafe Scout client engine (extension).
 * Same layers as web beta: extract → corpus → fabrication heuristics.
 */
(function (global) {
  const KNOWN = [
    { re: /Brown\s+v\.\s+Board/i, form: "Brown v. Board of Education, 347 U.S. 483 (1954)", conf: 0.98 },
    { re: /Loving\s+v\.\s+Virginia/i, form: "Loving v. Virginia, 388 U.S. 1 (1967)", conf: 0.97 },
    { re: /Marbury\s+v\.\s+Madison/i, form: "Marbury v. Madison, 5 U.S. (1 Cranch) 137 (1803)", conf: 0.99 },
    { re: /Miranda\s+v\.\s+Arizona/i, form: "Miranda v. Arizona, 384 U.S. 436 (1966)", conf: 0.96 },
    { re: /Obergefell/i, form: "Obergefell v. Hodges, 576 U.S. 644 (2015)", conf: 0.9 },
    { re: /Roe\s+v\.\s+Wade/i, form: "Roe v. Wade, 410 U.S. 113 (1973)", conf: 0.95 },
    { re: /Dobbs\s+v\.\s+Jackson/i, form: "Dobbs v. Jackson Women's Health Organization, 597 U.S. 215 (2022)", conf: 0.94 },
    { re: /Gideon\s+v\.\s+Wainwright/i, form: "Gideon v. Wainwright, 372 U.S. 335 (1963)", conf: 0.96 },
    { re: /Citizens\s+United/i, form: "Citizens United v. FEC, 558 U.S. 310 (2010)", conf: 0.93 },
    { re: /Chevron\s+U\.?S\.?A\.?/i, form: "Chevron U.S.A. Inc. v. NRDC, 467 U.S. 837 (1984)", conf: 0.92 },
  ];

  const CITE_RE =
    /([A-Z][A-Za-z0-9'&. -]{1,80}\s+v\.\s+[A-Z][A-Za-z0-9'&. -]{1,80}(?:,\s*[\d\sA-Za-z().§,/-]+)?(?:\s*\(\d{4}\))?|U\.S\.\s+Const\.?[^\n.]{0,50}|\d+\s+U\.S\.C\.\s*§?\s*[\d\w()-]+|\d+\s+C\.F\.R\.\s*§?\s*[\d.]+|Fed\.\s*R\.\s*(?:Civ|Crim|Evid|App)\.\s*P\.\s*[\d.]+)/g;

  function extractCitations(text) {
    const found = new Set();
    const re = new RegExp(CITE_RE.source, "g");
    let m;
    while ((m = re.exec(text || "")) !== null) {
      const raw = m[1].trim().replace(/\s+/g, " ");
      if (raw.length > 5) found.add(raw);
    }
    return Array.from(found).slice(0, 60);
  }

  function fakeSignals(raw) {
    const hits = [];
    if (/\b(2099|2088|2077|999\s+F\.)\b/i.test(raw)) hits.push("impossible-year-or-volume");
    if (/\b(Imaginary|Fake|Hallucin|Made.?Up|Nonsuch)\b/i.test(raw)) hits.push("fabricated-party-name");
    if (/\bF\.99\b/i.test(raw)) hits.push("nonexistent-reporter");
    const y = raw.match(/\b(20\d{2})\b/);
    if (y && Number(y[1]) > new Date().getFullYear() + 1) hits.push("future-year");
    return hits;
  }

  function reporterForm(raw) {
    if (/\b\d+\s+U\.S\.\s+\d+/i.test(raw)) return { ok: true, note: "U.S. Reports form" };
    if (/\b\d+\s+S\.\s*Ct\.\s+\d+/i.test(raw)) return { ok: true, note: "S. Ct. form" };
    if (/\b\d+\s+F\.(?:2d|3d|4th)\s+\d+/i.test(raw)) return { ok: true, note: "Federal Reporter form" };
    if (/\b\d+\s+F\.\s*Supp\.(?:\s*2d|\s*3d)?\s+\d+/i.test(raw)) return { ok: true, note: "F. Supp. form" };
    if (/v\./i.test(raw) && !/\d{4}/.test(raw)) return { ok: false, note: "Case name without year/reporter" };
    if (/v\./i.test(raw)) return { ok: false, note: "Case name; incomplete reporter line" };
    return { ok: false, note: "Non-case or incomplete form" };
  }

  function classify(raw) {
    for (const k of KNOWN) {
      if (k.re.test(raw)) {
        return {
          type: "case",
          status: "verified",
          confidence: k.conf,
          reason: "Matched known authority corpus. " + k.form,
          source: "CiteSafe corpus",
          verified_form: k.form,
        };
      }
    }
    const fakes = fakeSignals(raw);
    if (fakes.length) {
      return {
        type: "case",
        status: "could_not_verify",
        confidence: Math.min(0.96, 0.75 + fakes.length * 0.08),
        reason:
          "High fabrication risk (" +
          fakes.join(", ") +
          "). Do not produce or file until proven on a primary source.",
        suggested: "Remove or replace before production.",
      };
    }
    if (/U\.S\.\s+Const/i.test(raw)) {
      return {
        type: "constitution",
        status: "verified",
        confidence: 0.94,
        reason: "Constitutional citation form recognized.",
      };
    }
    if (/\d+\s+U\.S\.C\./i.test(raw)) {
      return {
        type: "statute",
        status: "needs_review",
        confidence: 0.72,
        reason: "U.S.C. form detected. Confirm before production.",
      };
    }
    if (/\d+\s+C\.F\.R\./i.test(raw)) {
      return {
        type: "regulation",
        status: "needs_review",
        confidence: 0.7,
        reason: "C.F.R. form detected. Confirm section currency.",
      };
    }
    if (/Fed\.\s*R\./i.test(raw)) {
      return {
        type: "rule",
        status: "needs_review",
        confidence: 0.75,
        reason: "Federal rule form detected. Confirm rule number and text.",
      };
    }
    const form = reporterForm(raw);
    if (form.ok) {
      return {
        type: "case",
        status: "needs_review",
        confidence: 0.58,
        reason: "Plausible " + form.note + ". Existence not confirmed in local corpus.",
      };
    }
    if (/\bv\.\b/i.test(raw)) {
      return {
        type: "case",
        status: "needs_review",
        confidence: 0.45,
        reason: form.note + ". Incomplete line; expand before production.",
        suggested: "Add volume, reporter, page, and year.",
      };
    }
    return {
      type: "secondary",
      status: "needs_review",
      confidence: 0.38,
      reason: "Could not fully parse. Review manually before production.",
    };
  }

  async function runVerification(text) {
    const raws = extractCitations(text);
    const citations = (raws.length ? raws : ["(no citations detected)"]).map(function (original, i) {
      if (original.startsWith("(")) {
        return {
          id: "c-" + i,
          original: original,
          type: "case",
          status: "needs_review",
          confidence: 0,
          reason: "Paste text containing legal citations.",
        };
      }
      return Object.assign({ id: "c-" + i, original: original }, classify(original));
    });
    const verified = citations.filter(function (c) {
      return c.status === "verified";
    }).length;
    const needs_review = citations.filter(function (c) {
      return c.status === "needs_review";
    }).length;
    const could_not_verify = citations.filter(function (c) {
      return c.status === "could_not_verify";
    }).length;
    const total = citations.length;
    return {
      citations: citations,
      summary: {
        total: total,
        verified: verified,
        needs_review: needs_review,
        could_not_verify: could_not_verify,
        rate: total ? Math.round((verified / total) * 100) : 0,
      },
      timestamp: new Date().toISOString(),
      engine: "extension-scout-1.0",
    };
  }

  const SAMPLE =
    "Brown v. Board of Education, 347 U.S. 483 (1954).\n" +
    "Loving v. Virginia, 388 U.S. 1 (1967).\n" +
    "Smith v. Imaginary Holdings, 999 F.99 1 (2099).\n" +
    "Roe v. Fake Circuit, 123 F.4th 999 (2028).\n" +
    "42 U.S.C. § 1983. Miranda v. Arizona, 384 U.S. 436 (1966).";

  global.CiteSafeVerify = {
    runVerification: runVerification,
    extractCitations: extractCitations,
    SAMPLE: SAMPLE,
    STATUS_LABEL: {
      verified: "Verified",
      needs_review: "Needs Review",
      could_not_verify: "Could Not Verify",
    },
  };
})(typeof self !== "undefined" ? self : globalThis);
