const textEl = document.getElementById("text");
const runBtn = document.getElementById("run");
const sampleBtn = document.getElementById("sample");
const selBtn = document.getElementById("sel");
const resultsEl = document.getElementById("results");
const summaryEl = document.getElementById("summary");

const LABEL = CiteSafeVerify.STATUS_LABEL;

function statusClass(s) {
  if (s === "verified") return "v";
  if (s === "could_not_verify") return "f";
  return "r";
}

function render(data) {
  const s = data.summary;
  summaryEl.classList.remove("hidden");
  summaryEl.innerHTML =
    '<span class="pill n">' +
    s.total +
    " cites</span>" +
    '<span class="pill v">' +
    s.verified +
    " verified</span>" +
    '<span class="pill r">' +
    s.needs_review +
    " review</span>" +
    '<span class="pill f">' +
    s.could_not_verify +
    " fail</span>";

  resultsEl.innerHTML = "";
  data.citations.forEach(function (c) {
    const sc = statusClass(c.status);
    const div = document.createElement("div");
    div.className = "card" + (c.status === "could_not_verify" ? " fail" : "");
    div.innerHTML =
      '<div class="cite"></div>' +
      '<div class="meta ' +
      sc +
      '"></div>' +
      '<div class="reason"></div>';
    div.querySelector(".cite").textContent = c.original;
    div.querySelector(".meta").textContent =
      LABEL[c.status] + " · " + Math.round((c.confidence || 0) * 100) + "%";
    div.querySelector(".reason").textContent = c.reason || "";
    resultsEl.appendChild(div);
  });
}

async function run() {
  const text = textEl.value.trim();
  if (!text) {
    textEl.focus();
    return;
  }
  runBtn.disabled = true;
  runBtn.textContent = "Checking…";
  try {
    const data = await CiteSafeVerify.runVerification(text);
    render(data);
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = "Check cites";
  }
}

sampleBtn.addEventListener("click", function () {
  textEl.value = CiteSafeVerify.SAMPLE;
});

selBtn.addEventListener("click", function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    chrome.tabs.sendMessage(tab.id, { type: "GET_SELECTION" }, function (res) {
      if (chrome.runtime.lastError) {
        chrome.runtime.sendMessage({ type: "GET_PENDING" }, function (pend) {
          if (pend && pend.text) textEl.value = pend.text;
        });
        return;
      }
      if (res && res.text) textEl.value = res.text;
    });
  });
});

runBtn.addEventListener("click", run);

chrome.runtime.sendMessage({ type: "GET_PENDING" }, function (pend) {
  if (pend && pend.text) {
    textEl.value = pend.text;
    run();
  }
});
