chrome.runtime.onInstalled.addListener(function () {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({
      id: "citesafe-verify-selection",
      title: "CiteSafe: check citations before production",
      contexts: ["selection"],
    });
  });
});

chrome.contextMenus.onClicked.addListener(function (info) {
  if (info.menuItemId !== "citesafe-verify-selection") return;
  const text = (info.selectionText || "").trim();
  if (!text) return;
  chrome.storage.local.set({ pendingText: text, pendingAt: Date.now() }, function () {
    chrome.action.openPopup().catch(function () {
      /* popup may fail if not user gesture on some builds; storage still set */
    });
  });
});

chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (msg && msg.type === "GET_PENDING") {
    chrome.storage.local.get(["pendingText"], function (data) {
      const t = data.pendingText || "";
      if (t) chrome.storage.local.remove("pendingText");
      sendResponse({ text: t });
    });
    return true;
  }
});
