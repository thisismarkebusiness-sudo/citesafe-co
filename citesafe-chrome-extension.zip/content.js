// Reserved for page selection handoff; context menu uses selectionText from Chrome.
chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (msg && msg.type === "GET_SELECTION") {
    sendResponse({ text: (window.getSelection() && window.getSelection().toString()) || "" });
    return true;
  }
});
