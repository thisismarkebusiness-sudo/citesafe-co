# CiteSafe Chrome extension

Scout 1.0 Beta. Check citations **before turning over documents or production**.

## Load unpacked (beta now)

1. Open Chrome → `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. **Load unpacked** → select this folder: `apps/extension`
4. Pin CiteSafe from the puzzle icon

## Use it

- Click the extension icon → paste text → **Check cites**
- Or highlight text on a page → right click → **CiteSafe: check citations before production**

## Chrome Web Store

Package is store ready (MV3). Publish when you have a Chrome developer account:

1. Zip the contents of `apps/extension` (not the parent folder)
2. [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole)
3. Upload zip → fill listing → submit

Until then, site install page points people at these steps.

## Not legal advice

Heuristic / corpus beta. Confirm critical cites on primary sources before filing or production.
